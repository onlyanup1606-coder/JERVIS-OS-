/* ================= JARVIS OS ENGINE ================= */
const cmdInput=document.getElementById('cmd');
const responseBox=document.getElementById('response');
const log=document.getElementById('log');
const micBtn=document.getElementById('micBtn');
const statusLine=document.getElementById('statusLine');
const clockLine=document.getElementById('clockLine');
const waveform=document.getElementById('waveform');
const langBn=document.getElementById('langBn');
const langEn=document.getElementById('langEn');

let currentLang = localStorage.getItem('jarvisLang') || 'bn';
setLang(currentLang);

function setLang(l){
  currentLang=l;
  localStorage.setItem('jarvisLang',l);
  langBn.classList.toggle('active', l==='bn');
  langEn.classList.toggle('active', l==='en');
}
langBn.addEventListener('click',()=>setLang('bn'));
langEn.addEventListener('click',()=>setLang('en'));

/* Boot sequence */
window.addEventListener('load',()=>{
  setTimeout(()=>{
    const boot=document.getElementById('boot');
    boot.style.opacity='0';
    setTimeout(()=>boot.style.display='none',800);
  },2600);
});

/* Live clock */
function tickClock(){
  const now=new Date();
  clockLine.textContent = now.toLocaleTimeString('bn-BD') + '  •  ' + now.toLocaleDateString('bn-BD');
}
tickClock();
setInterval(tickClock,1000);

/* Fake but live-feeling system stats */
setInterval(()=>{
  document.getElementById('cpu').textContent = (30+Math.floor(Math.random()*50))+'%';
  document.getElementById('ram').textContent = (25+Math.floor(Math.random()*45))+'%';
},1500);

function addLog(m){
  const d=document.createElement('div');
  d.innerHTML='<span>['+new Date().toLocaleTimeString()+']</span> '+m;
  log.appendChild(d); log.scrollTop=log.scrollHeight;
}

function speak(text){
  if(!('speechSynthesis' in window)) return;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.lang = currentLang==='bn' ? 'bn-BD' : 'en-IN';
  u.rate=1; u.pitch=1;
  const voices=speechSynthesis.getVoices();
  const match=voices.find(v=>v.lang && v.lang.toLowerCase().startsWith(u.lang.toLowerCase().slice(0,2)));
  if(match) u.voice=match;
  speechSynthesis.speak(u);
}

function openUrl(url){ window.open(url,'_blank'); }

function saveHistory(cmd){
  const h = JSON.parse(localStorage.getItem('jarvisHistory')||'[]');
  h.unshift(cmd);
  localStorage.setItem('jarvisHistory', JSON.stringify(h.slice(0,20)));
}

/* ================= COMMAND HANDLER ================= */
function handle(raw){
  const c = raw.trim();
  const lc = c.toLowerCase();
  addLog('&gt; '+c);
  saveHistory(c);
  let answer='';

  if(lc.includes('youtube')){
    let term = lc.replace(/youtube/g,'')
      .replace(/\b(e|te|play|chalao|chalabe|khulo|dekhao|dekhabe|search|koro|on|the|latest|video)\b/g,' ')
      .trim();
    if(term.length>1){
      openUrl('https://www.youtube.com/results?search_query='+encodeURIComponent(term));
      answer = currentLang==='bn' ? `"${term}" এর জন্য YouTube খুলে দিলাম।` : `Opening YouTube results for "${term}".`;
    } else {
      openUrl('https://www.youtube.com');
      answer = currentLang==='bn' ? 'YouTube খুলে দিলাম।' : 'Opening YouTube.';
    }
  }
  else if(lc.includes('google')){
    let term = lc.replace(/google/g,'').replace(/\b(e|te|search|koro|khulo)\b/g,' ').trim();
    if(term.length>1){
      openUrl('https://www.google.com/search?q='+encodeURIComponent(term));
      answer = currentLang==='bn' ? `"${term}" গুগলে সার্চ করে দিলাম।` : `Searching Google for "${term}".`;
    } else {
      openUrl('https://www.google.com');
      answer = currentLang==='bn' ? 'Google খুলে দিলাম।' : 'Opening Google.';
    }
  }
  else if(lc.includes('map') || lc.includes('ম্যাপ')){
    openUrl('https://www.google.com/maps');
    answer = currentLang==='bn' ? 'Maps খুলে দিলাম।' : 'Opening Maps.';
  }
  else if(lc.includes('whatsapp') || lc.includes('হোয়াটসঅ্যাপ')){
    openUrl('https://web.whatsapp.com');
    answer = currentLang==='bn' ? 'WhatsApp Web খুলে দিলাম।' : 'Opening WhatsApp Web.';
  }
  else if(lc.includes('facebook') || lc.includes('ফেসবুক')){
    openUrl('https://www.facebook.com');
    answer = currentLang==='bn' ? 'Facebook খুলে দিলাম।' : 'Opening Facebook.';
  }
  else if(lc.includes('gmail') || lc.includes('mail')){
    openUrl('https://mail.google.com');
    answer = currentLang==='bn' ? 'Gmail খুলে দিলাম।' : 'Opening Gmail.';
  }
  else if(/^\s*[\d\.\+\-\*\/\(\)\s]+$/.test(c) && /[\d]/.test(c) && /[\+\-\*\/]/.test(c)){
    try{
      const result = Function('"use strict";return ('+c+')')();
      answer = currentLang==='bn' ? `উত্তর হলো ${result}` : `The answer is ${result}`;
    }catch(e){
      answer = currentLang==='bn' ? 'হিসাবটা বুঝতে পারিনি।' : "Couldn't calculate that.";
    }
  }
  else if(lc.includes('time') || lc.includes('সময়')){
    answer = (currentLang==='bn'?'এখন সময় ':'The time is ')+new Date().toLocaleTimeString('bn-BD');
  }
  else if(lc.includes('date') || lc.includes('তারিখ')){
    answer = (currentLang==='bn'?'আজকের তারিখ ':"Today's date is ")+new Date().toLocaleDateString('bn-BD');
  }
  else if(lc.includes('hello')||lc.includes('hi')||lc.includes('হ্যালো')){
    answer = currentLang==='bn' ? 'নমস্কার! আমি JARVIS। সব সিস্টেম চালু আছে।' : 'Hello! I am JARVIS. All systems operational.';
  }
  else if(lc.includes('who are you')||lc.includes('tumi ke')){
    answer = currentLang==='bn' ? 'আমি JARVIS OS — তোমার ব্যক্তিগত AI সহকারী।' : 'I am JARVIS OS, your personal AI assistant.';
  }
  else if(lc==='help'||lc.includes('সাহায্য')){
    answer = currentLang==='bn'
      ? 'বলো: "youtube e [কিছু] chalao", "google e [কিছু] search koro", WhatsApp, Facebook, Gmail, Maps, সময়, তারিখ, অথবা যেকোনো হিসাব (যেমন 25*4)।'
      : 'Try: "youtube [something]", "google [something]", WhatsApp, Facebook, Gmail, Maps, time, date, or any calculation.';
  }
  else if(lc==='clear'||lc.includes('মুছ')){
    log.innerHTML=''; answer = currentLang==='bn' ? 'লগ মুছে দিলাম।' : 'Log cleared.';
  }
  else{
    openUrl('https://www.google.com/search?q='+encodeURIComponent(c));
    answer = currentLang==='bn' ? `বুঝিনি ঠিকভাবে, তাই গুগলে "${c}" সার্চ করে দিলাম।` : `Not sure, so I searched Google for "${c}".`;
  }

  responseBox.textContent = answer;
  addLog(answer);
  speak(answer);
  cmdInput.value='';
}

document.getElementById('sendBtn').addEventListener('click',()=>{
  if(cmdInput.value.trim()) handle(cmdInput.value);
});
cmdInput.addEventListener('keydown',e=>{
  if(e.key==='Enter' && cmdInput.value.trim()) handle(cmdInput.value);
});
document.querySelectorAll('.qbtn').forEach(b=>{
  b.addEventListener('click',()=>handle(b.dataset.q));
});

/* ================= VOICE ================= */
let recognizing=false;
micBtn.addEventListener('click',()=>{
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SR){
    responseBox.textContent = currentLang==='bn' ? 'এই ব্রাউজারে ভয়েস সাপোর্ট নেই। Chrome ব্যবহার করো।' : 'Voice not supported. Use Chrome.';
    return;
  }
  if(recognizing) return;
  const rec = new SR();
  rec.lang = currentLang==='bn' ? 'bn-BD' : 'en-IN';
  rec.interimResults=false;
  recognizing=true;
  micBtn.classList.add('listening');
  waveform.classList.add('show');
  statusLine.textContent = currentLang==='bn' ? 'শুনছি...' : 'LISTENING...';
  rec.start();
  rec.onresult=(e)=>{
    const text=e.results[0][0].transcript;
    cmdInput.value=text;
    handle(text);
  };
  rec.onerror=()=>{
    addLog(currentLang==='bn' ? 'ভয়েস এরর — আবার চেষ্টা করো।' : 'Voice error — try again.');
  };
  rec.onend=()=>{
    recognizing=false;
    micBtn.classList.remove('listening');
    waveform.classList.remove('show');
    statusLine.textContent = currentLang==='bn' ? 'সিস্টেম রেডি • মাইকে চাপো' : 'SYSTEM READY • TAP MIC';
  };
});

/* ================= PARTICLE BACKGROUND ================= */
const canvas=document.getElementById('particles');
const ctx=canvas.getContext('2d');
let particles=[];
function resizeCanvas(){ canvas.width=innerWidth; canvas.height=innerHeight; }
resizeCanvas();
window.addEventListener('resize',resizeCanvas);
for(let i=0;i<90;i++){
  particles.push({x:Math.random()*innerWidth,y:Math.random()*innerHeight,size:Math.random()*2+.4,speed:Math.random()*.4+.1,alpha:Math.random()});
}
function drawParticles(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  for(const p of particles){
    p.y+=p.speed;
    if(p.y>canvas.height){ p.y=0; p.x=Math.random()*canvas.width; }
    ctx.fillStyle=`rgba(0,234,255,${p.alpha})`;
    ctx.fillRect(p.x,p.y,p.size,p.size);
  }
  requestAnimationFrame(drawParticles);
}
drawParticles();

addLog('Kernel loaded.');
addLog('Neural interface initialized.');
addLog('Waiting for command...');

/* PWA install */
if('serviceWorker' in navigator){
  window.addEventListener('load',()=>{
    navigator.serviceWorker.register('sw.js').catch(()=>{});
  });
}
